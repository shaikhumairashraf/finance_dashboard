# Finance Dashboard Backend

A Spring Boot backend for a finance dashboard system featuring role-based access control, financial record management, and summary analytics.

## Tech Stack

| Component        | Technology                          |
|-----------------|-------------------------------------|
| Language         | Java 17                            |
| Framework        | Spring Boot 3.2.5                  |
| Security         | Spring Security + JWT (jjwt 0.12.5)|
| Database         | H2 (in-memory)                     |
| ORM              | Spring Data JPA / Hibernate        |
| Validation       | Jakarta Bean Validation            |
| API Docs         | SpringDoc OpenAPI (Swagger UI)     |
| Build Tool       | Maven                              |
| Testing          | JUnit 5, MockMvc, Spring Test      |

## Architecture

```
com.finance.dashboard
├── config/          # Security config, JWT filter, data initializer, OpenAPI config
├── controller/      # REST controllers (Auth, User, Record, Dashboard)
├── dto/             # Request/response DTOs organized by domain
│   ├── auth/        # Register, Login, AuthResponse
│   ├── user/        # User CRUD DTOs
│   ├── record/      # Financial record DTOs
│   └── dashboard/   # Summary, trends, category DTOs
├── entity/          # JPA entities (User, FinancialRecord)
├── enums/           # Role, TransactionType
├── exception/       # Custom exceptions + global handler
├── repository/      # Spring Data JPA repositories
├── service/         # Business logic layer
└── util/            # JWT utility
```

## Setup & Running

### Prerequisites
- Java 17+ (JDK)
- Maven 3.8+

### Run the Application
```bash
cd finance-dashboard
mvn spring-boot:run
```

The server starts on **http://localhost:8080**.

### Run Tests
```bash
mvn test
```

### Access Points
| URL                                      | Description              |
|------------------------------------------|--------------------------|
| http://localhost:8080/swagger-ui.html     | Swagger UI (API docs)    |
| http://localhost:8080/h2-console          | H2 Database Console      |
| http://localhost:8080/api-docs            | OpenAPI JSON spec        |

> **H2 Console**: JDBC URL = `jdbc:h2:mem:financedb`, Username = `sa`, Password = (empty)

## Default Users (Seeded on Startup)

| Username  | Password     | Role    |
|-----------|-------------|---------|
| admin     | admin123    | ADMIN   |
| analyst   | analyst123  | ANALYST |
| viewer    | viewer123   | VIEWER  |

## Roles & Permissions

| Action                     | VIEWER | ANALYST | ADMIN |
|---------------------------|--------|---------|-------|
| View financial records     | ✅     | ✅      | ✅    |
| Access dashboard/analytics | ❌     | ✅      | ✅    |
| Create/update/delete records | ❌   | ❌      | ✅    |
| Manage users               | ❌     | ❌      | ✅    |

## API Reference

### Authentication
| Method | Endpoint             | Description                          | Auth |
|--------|---------------------|--------------------------------------|------|
| POST   | `/api/auth/register` | Register a new user                  | No   |
| POST   | `/api/auth/login`    | Login and receive JWT token          | No   |

> The first registered user is automatically assigned the **ADMIN** role. Subsequent users default to **VIEWER**.

### User Management (Admin Only)
| Method | Endpoint                  | Description              |
|--------|--------------------------|--------------------------|
| GET    | `/api/users`             | List all users           |
| GET    | `/api/users/{id}`        | Get user by ID           |
| PUT    | `/api/users/{id}`        | Update user details      |
| PATCH  | `/api/users/{id}/role`   | Change user role         |
| PATCH  | `/api/users/{id}/status` | Activate/deactivate user |
| DELETE | `/api/users/{id}`        | Delete user              |

### Financial Records
| Method | Endpoint             | Description                        | Roles          |
|--------|---------------------|------------------------------------|----------------|
| POST   | `/api/records`      | Create a record                    | ADMIN          |
| GET    | `/api/records`      | List records (with filters/paging) | ALL            |
| GET    | `/api/records/{id}` | Get a specific record              | ALL            |
| PUT    | `/api/records/{id}` | Update a record                    | ADMIN          |
| DELETE | `/api/records/{id}` | Soft-delete a record               | ADMIN          |

**Query Parameters for GET `/api/records`:**
| Param     | Type   | Description                              |
|-----------|--------|------------------------------------------|
| type      | Enum   | `INCOME` or `EXPENSE`                    |
| category  | String | Filter by category name                  |
| startDate | Date   | Records from this date (YYYY-MM-DD)      |
| endDate   | Date   | Records until this date (YYYY-MM-DD)     |
| search    | String | Search in description                    |
| page      | int    | Page number (0-based, default: 0)        |
| size      | int    | Page size (default: 20)                  |
| sort      | String | Sort field,direction (default: date,desc)|

### Dashboard (Analyst + Admin)
| Method | Endpoint                       | Description                              |
|--------|-------------------------------|------------------------------------------|
| GET    | `/api/dashboard/summary`       | Full summary (income, expenses, balance) |
| GET    | `/api/dashboard/category-totals` | Totals grouped by category and type    |
| GET    | `/api/dashboard/monthly-trends`  | Monthly income/expense trends          |
| GET    | `/api/dashboard/recent-activity` | Recent transactions (default: 10)      |

## Example Usage (cURL)

### Register
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"john","email":"john@example.com","password":"secret123"}'
```

### Login
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

### Create a Record (Admin)
```bash
curl -X POST http://localhost:8080/api/records \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <TOKEN>" \
  -d '{"amount":1500,"type":"INCOME","category":"Salary","date":"2026-04-01","description":"Monthly salary"}'
```

### Get Dashboard Summary
```bash
curl http://localhost:8080/api/dashboard/summary \
  -H "Authorization: Bearer <TOKEN>"
```

### Filter Records
```bash
curl "http://localhost:8080/api/records?type=EXPENSE&category=Rent&startDate=2026-01-01&endDate=2026-12-31&page=0&size=10" \
  -H "Authorization: Bearer <TOKEN>"
```

## Design Decisions & Assumptions

1. **H2 In-Memory Database**: Chosen for simplicity and zero-configuration setup. Data resets on restart. The seeder (`DataInitializer`) populates sample data on each boot.

2. **JWT Authentication**: Stateless token-based auth. Tokens expire after 24 hours. No refresh token mechanism (kept simple for assessment scope).

3. **First-User-as-Admin**: The first user to register is automatically granted ADMIN role. This avoids needing a separate admin setup process.

4. **Soft Delete**: Financial records use soft delete (`deleted` flag) to preserve audit trails. Deleted records are excluded from all queries and dashboard calculations.

5. **Role-Based Access Control**: Enforced at two levels:
   - **URL-level**: Spring Security `HttpSecurity` rules in `SecurityConfig`
   - **Behavioral**: Service-layer logic prevents unsafe operations (e.g., deleting the last admin)

6. **Pagination**: Record listing uses Spring Data's `Pageable` with configurable page size, sorting, and filtering.

7. **Input Validation**: Jakarta Bean Validation annotations on all DTOs with a global exception handler that returns structured error responses with field-level detail.

8. **Error Responses**: Consistent `ErrorResponse` format across all error types (validation, not found, auth, etc.) with proper HTTP status codes.

## Project Structure Rationale

- **Controller → Service → Repository** layering for clean separation of concerns
- **DTOs** separate API contract from JPA entities; prevents exposing internal data (e.g., passwords)
- **Global Exception Handler** centralizes error response formatting
- **Security Filter Chain** handles JWT validation before any controller logic

## Potential Enhancements (Not Implemented)

- Refresh tokens for extended sessions
- Rate limiting with Spring Cloud Gateway or Bucket4j
- Audit logging for financial record changes
- Export endpoints (CSV/PDF)
- Multi-tenant support
- Caching for dashboard aggregations
- Docker containerization
