package com.finance.dashboard.dto.dashboard;

import com.finance.dashboard.enums.TransactionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MonthlyTrend {
    private int year;
    private int month;
    private TransactionType type;
    private BigDecimal total;
}
