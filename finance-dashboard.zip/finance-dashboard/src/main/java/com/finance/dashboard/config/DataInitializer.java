package com.finance.dashboard.config;

import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.entity.User;
import com.finance.dashboard.enums.Role;
import com.finance.dashboard.enums.TransactionType;
import com.finance.dashboard.repository.FinancialRecordRepository;
import com.finance.dashboard.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Seeds the database with sample data for demonstration purposes.
 * Creates default users (admin, analyst, viewer) and sample financial records.
 */
@Component
@RequiredArgsConstructor
@Slf4j
@Profile("!test")
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final FinancialRecordRepository recordRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (userRepository.count() > 0) {
            log.info("Database already contains data. Skipping initialization.");
            return;
        }

        log.info("Initializing sample data...");

        // Create users
        User admin = userRepository.save(User.builder()
                .username("admin")
                .email("admin@finance.com")
                .password(passwordEncoder.encode("admin123"))
                .role(Role.ADMIN)
                .active(true)
                .build());

        userRepository.save(User.builder()
                .username("analyst")
                .email("analyst@finance.com")
                .password(passwordEncoder.encode("analyst123"))
                .role(Role.ANALYST)
                .active(true)
                .build());

        userRepository.save(User.builder()
                .username("viewer")
                .email("viewer@finance.com")
                .password(passwordEncoder.encode("viewer123"))
                .role(Role.VIEWER)
                .active(true)
                .build());

        // Create sample financial records
        List<FinancialRecord> records = List.of(
                buildRecord(new BigDecimal("5000.00"), TransactionType.INCOME, "Salary",
                        LocalDate.of(2026, 3, 1), "Monthly salary", admin),
                buildRecord(new BigDecimal("1200.00"), TransactionType.EXPENSE, "Rent",
                        LocalDate.of(2026, 3, 2), "Office rent payment", admin),
                buildRecord(new BigDecimal("350.00"), TransactionType.EXPENSE, "Utilities",
                        LocalDate.of(2026, 3, 5), "Electricity and internet", admin),
                buildRecord(new BigDecimal("2000.00"), TransactionType.INCOME, "Freelance",
                        LocalDate.of(2026, 3, 10), "Web development project", admin),
                buildRecord(new BigDecimal("150.00"), TransactionType.EXPENSE, "Office Supplies",
                        LocalDate.of(2026, 3, 12), "Stationery and printer ink", admin),
                buildRecord(new BigDecimal("800.00"), TransactionType.EXPENSE, "Marketing",
                        LocalDate.of(2026, 3, 15), "Social media ads campaign", admin),
                buildRecord(new BigDecimal("3500.00"), TransactionType.INCOME, "Consulting",
                        LocalDate.of(2026, 3, 18), "Financial advisory fees", admin),
                buildRecord(new BigDecimal("200.00"), TransactionType.EXPENSE, "Travel",
                        LocalDate.of(2026, 3, 20), "Client meeting travel", admin),
                buildRecord(new BigDecimal("5000.00"), TransactionType.INCOME, "Salary",
                        LocalDate.of(2026, 4, 1), "Monthly salary - April", admin),
                buildRecord(new BigDecimal("450.00"), TransactionType.EXPENSE, "Insurance",
                        LocalDate.of(2026, 4, 3), "Business insurance premium", admin),
                // Historical records for trends
                buildRecord(new BigDecimal("5000.00"), TransactionType.INCOME, "Salary",
                        LocalDate.of(2026, 2, 1), "Monthly salary - February", admin),
                buildRecord(new BigDecimal("1200.00"), TransactionType.EXPENSE, "Rent",
                        LocalDate.of(2026, 2, 2), "Office rent - February", admin),
                buildRecord(new BigDecimal("1500.00"), TransactionType.INCOME, "Freelance",
                        LocalDate.of(2026, 2, 15), "Design project", admin),
                buildRecord(new BigDecimal("5000.00"), TransactionType.INCOME, "Salary",
                        LocalDate.of(2026, 1, 1), "Monthly salary - January", admin),
                buildRecord(new BigDecimal("1200.00"), TransactionType.EXPENSE, "Rent",
                        LocalDate.of(2026, 1, 2), "Office rent - January", admin)
        );

        recordRepository.saveAll(records);
        log.info("Sample data initialized: {} users, {} records", userRepository.count(), recordRepository.count());
    }

    private FinancialRecord buildRecord(BigDecimal amount, TransactionType type, String category,
                                         LocalDate date, String description, User createdBy) {
        return FinancialRecord.builder()
                .amount(amount)
                .type(type)
                .category(category)
                .date(date)
                .description(description)
                .createdBy(createdBy)
                .build();
    }
}
