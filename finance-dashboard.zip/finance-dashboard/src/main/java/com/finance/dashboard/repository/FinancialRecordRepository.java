package com.finance.dashboard.repository;

import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.enums.TransactionType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface FinancialRecordRepository extends JpaRepository<FinancialRecord, Long>,
        JpaSpecificationExecutor<FinancialRecord> {

    Optional<FinancialRecord> findByIdAndDeletedFalse(Long id);

    Page<FinancialRecord> findByDeletedFalse(Pageable pageable);

    // --- Aggregation queries for dashboard ---

    @Query("SELECT COALESCE(SUM(r.amount), 0) FROM FinancialRecord r " +
            "WHERE r.type = :type AND r.deleted = false")
    BigDecimal sumByType(@Param("type") TransactionType type);

    @Query("SELECT COUNT(r) FROM FinancialRecord r WHERE r.deleted = false")
    long countActive();

    @Query("SELECT r.category, r.type, SUM(r.amount) FROM FinancialRecord r " +
            "WHERE r.deleted = false GROUP BY r.category, r.type ORDER BY r.category")
    List<Object[]> getCategoryTotals();

    @Query("SELECT YEAR(r.date), MONTH(r.date), r.type, SUM(r.amount) " +
            "FROM FinancialRecord r WHERE r.deleted = false " +
            "GROUP BY YEAR(r.date), MONTH(r.date), r.type " +
            "ORDER BY YEAR(r.date) DESC, MONTH(r.date) DESC")
    List<Object[]> getMonthlyTrends();

    @Query("SELECT r FROM FinancialRecord r WHERE r.deleted = false ORDER BY r.date DESC, r.createdAt DESC")
    List<FinancialRecord> findRecentActivity(Pageable pageable);

    // --- Filtered queries ---

    @Query("SELECT r FROM FinancialRecord r WHERE r.deleted = false " +
            "AND (:type IS NULL OR r.type = :type) " +
            "AND (:category IS NULL OR r.category = :category) " +
            "AND (:startDate IS NULL OR r.date >= :startDate) " +
            "AND (:endDate IS NULL OR r.date <= :endDate) " +
            "AND (:search IS NULL OR LOWER(r.description) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<FinancialRecord> findWithFilters(
            @Param("type") TransactionType type,
            @Param("category") String category,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate,
            @Param("search") String search,
            Pageable pageable);
}
