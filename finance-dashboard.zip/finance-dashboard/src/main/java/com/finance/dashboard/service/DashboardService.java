package com.finance.dashboard.service;

import com.finance.dashboard.dto.dashboard.*;
import com.finance.dashboard.entity.FinancialRecord;
import com.finance.dashboard.enums.TransactionType;
import com.finance.dashboard.repository.FinancialRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class DashboardService {

    private final FinancialRecordRepository recordRepository;

    public DashboardSummary getSummary() {
        BigDecimal totalIncome = recordRepository.sumByType(TransactionType.INCOME);
        BigDecimal totalExpenses = recordRepository.sumByType(TransactionType.EXPENSE);
        BigDecimal netBalance = totalIncome.subtract(totalExpenses);
        long totalRecords = recordRepository.countActive();

        List<CategoryTotal> categoryTotals = getCategoryTotals();
        List<RecordSummary> recentActivity = getRecentActivity(10);

        return DashboardSummary.builder()
                .totalIncome(totalIncome)
                .totalExpenses(totalExpenses)
                .netBalance(netBalance)
                .totalRecords(totalRecords)
                .categoryTotals(categoryTotals)
                .recentActivity(recentActivity)
                .build();
    }

    public List<CategoryTotal> getCategoryTotals() {
        return recordRepository.getCategoryTotals().stream()
                .map(row -> CategoryTotal.builder()
                        .category((String) row[0])
                        .type((TransactionType) row[1])
                        .total((BigDecimal) row[2])
                        .build())
                .collect(Collectors.toList());
    }

    public List<MonthlyTrend> getMonthlyTrends() {
        return recordRepository.getMonthlyTrends().stream()
                .map(row -> MonthlyTrend.builder()
                        .year((Integer) row[0])
                        .month((Integer) row[1])
                        .type((TransactionType) row[2])
                        .total((BigDecimal) row[3])
                        .build())
                .collect(Collectors.toList());
    }

    public List<RecordSummary> getRecentActivity(int limit) {
        List<FinancialRecord> records = recordRepository
                .findRecentActivity(PageRequest.of(0, limit));
        return records.stream()
                .map(r -> RecordSummary.builder()
                        .id(r.getId())
                        .amount(r.getAmount())
                        .type(r.getType())
                        .category(r.getCategory())
                        .date(r.getDate())
                        .description(r.getDescription())
                        .build())
                .collect(Collectors.toList());
    }
}
