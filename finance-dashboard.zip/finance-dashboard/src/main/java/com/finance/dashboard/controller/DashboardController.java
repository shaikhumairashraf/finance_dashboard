package com.finance.dashboard.controller;

import com.finance.dashboard.dto.dashboard.CategoryTotal;
import com.finance.dashboard.dto.dashboard.DashboardSummary;
import com.finance.dashboard.dto.dashboard.MonthlyTrend;
import com.finance.dashboard.dto.dashboard.RecordSummary;
import com.finance.dashboard.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard", description = "Dashboard summary and analytics APIs")
@SecurityRequirement(name = "bearerAuth")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/summary")
    @Operation(summary = "Get full dashboard summary",
            description = "Returns total income, expenses, net balance, category totals, and recent activity")
    public ResponseEntity<DashboardSummary> getSummary() {
        return ResponseEntity.ok(dashboardService.getSummary());
    }

    @GetMapping("/category-totals")
    @Operation(summary = "Get category-wise totals")
    public ResponseEntity<List<CategoryTotal>> getCategoryTotals() {
        return ResponseEntity.ok(dashboardService.getCategoryTotals());
    }

    @GetMapping("/monthly-trends")
    @Operation(summary = "Get monthly income/expense trends")
    public ResponseEntity<List<MonthlyTrend>> getMonthlyTrends() {
        return ResponseEntity.ok(dashboardService.getMonthlyTrends());
    }

    @GetMapping("/recent-activity")
    @Operation(summary = "Get recent financial activity")
    public ResponseEntity<List<RecordSummary>> getRecentActivity(
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(dashboardService.getRecentActivity(Math.min(limit, 50)));
    }
}
