package com.finance.dashboard.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finance.dashboard.dto.auth.AuthResponse;
import com.finance.dashboard.dto.auth.RegisterRequest;
import com.finance.dashboard.dto.record.RecordRequest;
import com.finance.dashboard.enums.TransactionType;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@org.springframework.test.context.ActiveProfiles("test")
class DashboardControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static String adminToken;
    private static String viewerToken;

    @BeforeAll
    static void setup(@Autowired MockMvc mockMvc, @Autowired ObjectMapper objectMapper) throws Exception {
        // Register admin
        RegisterRequest adminReg = new RegisterRequest("dashadmin", "dashadmin@test.com", "password123");
        MvcResult adminResult = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(adminReg)))
                .andReturn();
        adminToken = objectMapper.readValue(
                adminResult.getResponse().getContentAsString(), AuthResponse.class).getToken();

        // Register viewer
        RegisterRequest viewerReg = new RegisterRequest("dashviewer", "dashviewer@test.com", "password123");
        MvcResult viewerResult = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(viewerReg)))
                .andReturn();
        viewerToken = objectMapper.readValue(
                viewerResult.getResponse().getContentAsString(), AuthResponse.class).getToken();

        // Create some records for dashboard data
        RecordRequest income = new RecordRequest(
                new BigDecimal("3000.00"), TransactionType.INCOME, "Salary",
                LocalDate.of(2026, 4, 1), "Salary");
        RecordRequest expense = new RecordRequest(
                new BigDecimal("500.00"), TransactionType.EXPENSE, "Rent",
                LocalDate.of(2026, 4, 2), "Rent");

        mockMvc.perform(post("/api/records")
                .header("Authorization", "Bearer " + adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(income)));
        mockMvc.perform(post("/api/records")
                .header("Authorization", "Bearer " + adminToken)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(expense)));
    }

    @Test
    @Order(1)
    void admin_ShouldAccessDashboardSummary() throws Exception {
        mockMvc.perform(get("/api/dashboard/summary")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalIncome").isNumber())
                .andExpect(jsonPath("$.totalExpenses").isNumber())
                .andExpect(jsonPath("$.netBalance").isNumber())
                .andExpect(jsonPath("$.totalRecords").isNumber())
                .andExpect(jsonPath("$.categoryTotals").isArray())
                .andExpect(jsonPath("$.recentActivity").isArray());
    }

    @Test
    @Order(2)
    void viewer_ShouldNotAccessDashboard() throws Exception {
        mockMvc.perform(get("/api/dashboard/summary")
                        .header("Authorization", "Bearer " + viewerToken))
                .andExpect(status().isForbidden());
    }

    @Test
    @Order(3)
    void admin_ShouldGetCategoryTotals() throws Exception {
        mockMvc.perform(get("/api/dashboard/category-totals")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    @Order(4)
    void admin_ShouldGetMonthlyTrends() throws Exception {
        mockMvc.perform(get("/api/dashboard/monthly-trends")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }

    @Test
    @Order(5)
    void admin_ShouldGetRecentActivity() throws Exception {
        mockMvc.perform(get("/api/dashboard/recent-activity")
                        .header("Authorization", "Bearer " + adminToken)
                        .param("limit", "5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());
    }
}
