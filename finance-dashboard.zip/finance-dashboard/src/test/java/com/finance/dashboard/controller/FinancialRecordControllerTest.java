package com.finance.dashboard.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.finance.dashboard.dto.auth.AuthResponse;
import com.finance.dashboard.dto.auth.LoginRequest;
import com.finance.dashboard.dto.auth.RegisterRequest;
import com.finance.dashboard.dto.record.RecordRequest;
import com.finance.dashboard.enums.TransactionType;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@org.springframework.test.context.ActiveProfiles("test")
class FinancialRecordControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private static String adminToken;
    private static String viewerToken;

    @BeforeAll
    static void setup(@Autowired MockMvc mockMvc, @Autowired ObjectMapper objectMapper) throws Exception {
        // Register admin (first user)
        RegisterRequest adminReg = new RegisterRequest("recadmin", "recadmin@test.com", "password123");
        MvcResult adminResult = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(adminReg)))
                .andReturn();
        adminToken = objectMapper.readValue(
                adminResult.getResponse().getContentAsString(), AuthResponse.class).getToken();

        // Register viewer (second user, defaults to VIEWER)
        RegisterRequest viewerReg = new RegisterRequest("recviewer", "recviewer@test.com", "password123");
        MvcResult viewerResult = mockMvc.perform(post("/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(viewerReg)))
                .andReturn();
        viewerToken = objectMapper.readValue(
                viewerResult.getResponse().getContentAsString(), AuthResponse.class).getToken();
    }

    @Test
    @Order(1)
    void admin_ShouldCreateRecord() throws Exception {
        RecordRequest request = new RecordRequest(
                new BigDecimal("1500.00"), TransactionType.INCOME, "Salary",
                LocalDate.of(2026, 4, 1), "Monthly salary");

        mockMvc.perform(post("/api/records")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.amount").value(1500.00))
                .andExpect(jsonPath("$.type").value("INCOME"))
                .andExpect(jsonPath("$.category").value("Salary"));
    }

    @Test
    @Order(2)
    void viewer_ShouldNotCreateRecord() throws Exception {
        RecordRequest request = new RecordRequest(
                new BigDecimal("500.00"), TransactionType.EXPENSE, "Food",
                LocalDate.of(2026, 4, 1), "Lunch");

        mockMvc.perform(post("/api/records")
                        .header("Authorization", "Bearer " + viewerToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isForbidden());
    }

    @Test
    @Order(3)
    void viewer_ShouldReadRecords() throws Exception {
        mockMvc.perform(get("/api/records")
                        .header("Authorization", "Bearer " + viewerToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray());
    }

    @Test
    @Order(4)
    void admin_ShouldUpdateRecord() throws Exception {
        // First create a record
        RecordRequest createReq = new RecordRequest(
                new BigDecimal("200.00"), TransactionType.EXPENSE, "Transport",
                LocalDate.of(2026, 4, 2), "Bus fare");

        MvcResult createResult = mockMvc.perform(post("/api/records")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createReq)))
                .andReturn();

        String responseBody = createResult.getResponse().getContentAsString();
        Long recordId = objectMapper.readTree(responseBody).get("id").asLong();

        // Update the record
        RecordRequest updateReq = new RecordRequest(
                new BigDecimal("250.00"), TransactionType.EXPENSE, "Transport",
                LocalDate.of(2026, 4, 2), "Updated bus fare");

        mockMvc.perform(put("/api/records/" + recordId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateReq)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.amount").value(250.00))
                .andExpect(jsonPath("$.description").value("Updated bus fare"));
    }

    @Test
    @Order(5)
    void admin_ShouldDeleteRecord() throws Exception {
        // Create a record
        RecordRequest request = new RecordRequest(
                new BigDecimal("50.00"), TransactionType.EXPENSE, "Snacks",
                LocalDate.of(2026, 4, 3), "To be deleted");

        MvcResult result = mockMvc.perform(post("/api/records")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andReturn();

        Long recordId = objectMapper.readTree(
                result.getResponse().getContentAsString()).get("id").asLong();

        // Delete it
        mockMvc.perform(delete("/api/records/" + recordId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNoContent());

        // Verify it's gone (soft deleted)
        mockMvc.perform(get("/api/records/" + recordId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(6)
    void shouldValidateRecordInput() throws Exception {
        RecordRequest request = new RecordRequest(
                new BigDecimal("-10.00"), null, "",
                null, null);

        mockMvc.perform(post("/api/records")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors").isNotEmpty());
    }

    @Test
    @Order(7)
    void shouldFilterRecords() throws Exception {
        mockMvc.perform(get("/api/records")
                        .header("Authorization", "Bearer " + adminToken)
                        .param("type", "INCOME")
                        .param("category", "Salary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content").isArray());
    }
}
